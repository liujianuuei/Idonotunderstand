rm -rf __deployme
rm -rf js/build
rm -f bundle.js
rm -f discover-bundle.js
rm -f bundle.css
mkdir js/build

