watch "sh scripts/build.sh" js/source/ css/
