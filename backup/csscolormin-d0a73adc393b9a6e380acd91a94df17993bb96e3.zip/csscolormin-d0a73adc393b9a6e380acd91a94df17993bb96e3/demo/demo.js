var csscolormin = require('../index.js').min;

min = function(color) {
  return csscolormin(color);
};
